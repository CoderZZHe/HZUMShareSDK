//
//  HZUMShareSDK.h
//  HZUMShareSDK
//
//  Created by 何志志 on 2018/12/19.
//  Copyright © 2018 hezhizhi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HZUMShareSDK.
FOUNDATION_EXPORT double HZUMShareSDKVersionNumber;

//! Project version string for HZUMShareSDK.
FOUNDATION_EXPORT const unsigned char HZUMShareSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HZUMShareSDK/PublicHeader.h>


#import <UMShare/UMShare.h>
#import <UMCommon/UMCommon.h>

